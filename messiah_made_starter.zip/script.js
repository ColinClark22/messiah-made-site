// script.js - basic interactivity for the starter site
document.getElementById('year').textContent = new Date().getFullYear();

function openProduct(name){
  alert('Product: ' + name + '\nThis is a placeholder. Connect a cart service to enable purchases.');
}

function handleContact(e){
  e.preventDefault();
  const email = document.getElementById('email').value.trim();
  const message = document.getElementById('message').value.trim();
  if(!email || !message){ alert('Please fill the form.'); return; }
  alert('Thanks! Your message has been received (placeholder).\nEmail: ' + email);
  e.target.reset();
}
