Messiah Made — Starter static site template
------------------------------------------
Files:
  - index.html
  - style.css
  - script.js
  - README.txt

How to use:
  1. Download and unzip the files.
  2. Edit the HTML/CSS to match your brand (logo, colors, images).
  3. Push the files to your GitHub repo (root) and connect the repo to Netlify.
     - For a simple static site, leave the build command empty and publish directory as '/'.
  4. Netlify will auto-deploy on push. Your free site will be available at <site-name>.netlify.app.

Notes:
  - Replace placeholder images with your own product and lookbook photography.
  - To accept payments, integrate Ecwid, PayPal buttons, or a Stripe checkout flow.
  - This is a lightweight starter to get your Messiah Made brand online quickly.
